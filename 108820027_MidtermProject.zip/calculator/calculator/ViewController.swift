//
//  ViewController.swift
//  calculator
//
//  Created by Koro on 2022/3/21.
//

import UIKit
import Foundation

class ViewController: UIViewController {

    @IBOutlet weak var calculate: UILabel!
    @IBOutlet weak var result: UILabel!
    @IBOutlet weak var clearButton: UIButton!
    
    @IBOutlet var operatorButtons: [UIButton]!
    
    var resultNumber: Float = 0{
        didSet{
            if(resultNumber.truncatingRemainder(dividingBy: 1) != 0){
                result.text = String(resultNumber)
            }else{
                result.text = String(Int(resultNumber))
            }
            
        }
    }
    
    var cal_label: String = ""{
        didSet{
            calculate.text = cal_label
        }
    }
    
    var result_string_array: [String] = []
    
    var temp_number_array: [String] = []
    var temp_operator: String = ""
    var PAndN: Bool = false
    
    var clearAllFlag: Bool = true{
        didSet{
            if(clearAllFlag){
//                print("change to AC")
                clearButton.setTitle("AC", for: UIControl.State.normal)
            }else{
//                print("change to C")
                clearButton.setTitle("C", for: UIControl.State.normal)
            }
        }
    }
    
    var isFloatPoint: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func oneClicked(_ sender: UIButton) {
        let buttonTitle = sender.titleLabel?.text
//        print("click number")
        
        clearAllFlag = false
        RefreshOperatorButton()
        ClearOperatorTempVar()
        
        temp_number_array.append(buttonTitle!)
        
        RefreshCalLabelString()
    }
    
    @IBAction func floatPointClicked(_ sender: UIButton) {
        let buttonTitle = sender.titleLabel?.text
//        print("click floatPoint")
        if(!isFloatPoint){
            clearAllFlag = false
            
            RefreshOperatorButton()
            ClearOperatorTempVar()
            
            if(temp_number_array.isEmpty){
                temp_number_array.append("0")
            }
            
            temp_number_array.append(buttonTitle!)
//            print(temp_number_array)
            RefreshCalLabelString()
            isFloatPoint = true
        }
    }
    
    
    @IBAction func operatorClicked(_ sender: UIButton) {
        let buttonTitle = sender.titleLabel?.text
//        print("click operator")
        
        clearAllFlag = false
        RefreshOperatorButton()
        ClearTempVar()
        temp_operator = buttonTitle!
        
        RefreshCalLabelString()
        
        sender.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    }
    
    @IBAction func PNClicked(_ sender: Any) {
        if(!temp_number_array.isEmpty){
            PAndN = !PAndN
        }
        
        RefreshCalLabelString()
    }
    
    @IBAction func ACClicked(_ sender: Any) {
//        print("click clear button")
        if(clearAllFlag){
//            print("all clear")
            result_string_array.removeAll()
            temp_number_array.removeAll()
            temp_operator = ""
            resultNumber = 0
        }else{
            if(!temp_number_array.isEmpty){
                let temp = temp_number_array.removeLast()
                if(temp == "."){
                    isFloatPoint = false
                }
            }

            clearAllFlag = temp_number_array.isEmpty
            
            if(temp_number_array.isEmpty && temp_operator == "" && !result_string_array.isEmpty){
                temp_operator = result_string_array.removeLast()
                if(temp_operator == "＋"){
                    operatorButtons[0].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                }else if(temp_operator == "-"){
                    operatorButtons[1].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                }else if(temp_operator == "×"){
                    operatorButtons[2].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                }else if(temp_operator == "÷"){
                    operatorButtons[3].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                }else{
//                    print("last is number")
                    result_string_array.append(temp_operator)
                }
            }
        }
        
        RefreshCalLabelString()
        
    }
    
    @IBAction func PercentClicked(_ sender: Any) {
        if(!temp_number_array.isEmpty){
            temp_number_array.append("%")
        }
        
        RefreshCalLabelString()
    }
    
    @IBAction func getResult(_ sender: Any) {
        
//        print("getResult")
        var currentNumber: Float = 0
        var currentOperator: String = "＋"
        ClearTempVar()
        let fullCalculate = result_string_array
        
        RefreshOperatorButton()
        
        for cal in fullCalculate{
            if (cal == "＋" || cal == "-" || cal == "×" || cal == "÷"){
//                print("changeOperator")
                currentOperator = cal
            }else if (currentOperator == "＋"){
//                print("+")
                let newNumber = (cal as NSString).floatValue
                currentNumber = currentNumber + newNumber
            }else if (currentOperator == "-"){
//                print("-")
//                print(cal)
                let newNumber = (cal as NSString).floatValue
                currentNumber = currentNumber - newNumber
            }else if (currentOperator == "×"){
//                print("x")
//                print(cal)
                let newNumber = (cal as NSString).floatValue
                currentNumber = currentNumber * newNumber
            }else if (currentOperator == "÷"){
//                print("除掉數字")
//                print(cal)
                let newNumber = (cal as NSString).floatValue
                if (newNumber == 0){
                    currentNumber = 0
                }else{
                    currentNumber = currentNumber / newNumber
                }
            }
        }
        print("done")
        
        resultNumber = currentNumber
        RefreshCalLabelString()
        result_string_array.removeAll()
        temp_number_array.removeAll()
        temp_operator = ""
        clearAllFlag = true
    }
    
    func RefreshOperatorButton(){
        print("Refresh button called")
        for button: UIButton in operatorButtons{
            button.backgroundColor = #colorLiteral(red: 0.631372549, green: 0.8901960784, blue: 0.8470588235, alpha: 1)
        }
    }

    
    func ClearOperatorTempVar(){
//        print("clear temp operator called")
        if(temp_operator != ""){
            if(result_string_array.isEmpty){
                result_string_array.append("0")
            }
//            print("clear temp operator")
            result_string_array.append(temp_operator)
            temp_operator = ""
        }
    }
    
    func ClearTempVar(){
        if(!temp_number_array.isEmpty){
//            print("clear number")
            CleanFloatPointLastZero()
            
            var temp_string = ""
            if(PAndN){
                temp_string = temp_string + "-"
            }
            while(!temp_number_array.isEmpty){
                if(temp_number_array[0] == "0"){
                    temp_number_array.removeFirst()
                    if(temp_number_array.isEmpty){
                        temp_number_array.append("0")
                        break
                    }
                }else{
                    break
                }
            }
            
            while(!temp_number_array.isEmpty){
                let temp_point = temp_number_array.removeFirst()
                if(temp_point != "%"){
                    temp_string = temp_string + temp_point
                }else{
                    var temp_float: Float = (temp_string as NSString).floatValue
                    temp_float = temp_float / 100
                    temp_string = String(temp_float)
                }
            }
            result_string_array.append(temp_string)
            isFloatPoint = false
            PAndN = false
        }
    }
    
    func RefreshCalLabelString(){
        var i: Int = 0
        var result_string = ""
        while(i != result_string_array.count){
            result_string = result_string + result_string_array[i]
            result_string = result_string + " "
            i += 1
        }
        
        i = 0
        if(!temp_number_array.isEmpty){
            cal_label = result_string
            var temp_string: String = ""
            if(PAndN){
                temp_string = temp_string + "-"
            }
            while(i != temp_number_array.count){
                if(temp_number_array[i] == "%"){
                    var temp_float: Float = (temp_string as NSString).floatValue
                    temp_float = temp_float / 100
                    temp_string = String(temp_float)
                }else{
                    temp_string = temp_string + temp_number_array[i]
                }
                i += 1
            }
            cal_label = cal_label + temp_string
        }else if(temp_operator != ""){
            cal_label = result_string + temp_operator
        }else{
            cal_label = result_string
        }
    }
    
    func CleanFloatPointLastZero(){
        if(isFloatPoint){
            var cleanFinishFlag: Bool = true
            while(cleanFinishFlag){
                let temp_string = temp_number_array.removeLast()
                if(temp_string != "0"){
                    temp_number_array.append(temp_string)
                    cleanFinishFlag = false
                }
            }
        }
    }
}

